package com.techelevator.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"verified",
"sentCount"
})
public class Status {

@JsonProperty("verified")
private Boolean verified;
@JsonProperty("sentCount")
private Integer sentCount;

@JsonProperty("verified")
public Boolean getVerified() {
return verified;
}

@JsonProperty("verified")
public void setVerified(Boolean verified) {
this.verified = verified;
}

@JsonProperty("sentCount")
public Integer getSentCount() {
return sentCount;
}

@JsonProperty("sentCount")
public void setSentCount(Integer sentCount) {
this.sentCount = sentCount;
}

}