package com.techelevator.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.techelevator.dao.CatCardDao;
import com.techelevator.exception.DaoException;
import com.techelevator.model.CatCard;
import com.techelevator.model.CatPic;
import com.techelevator.services.CatFactService;
import com.techelevator.services.CatPicService;

@RestController
@RequestMapping("/api/cards")
public class CatController {

	private CatCardDao catCardDao;
	private CatFactService catFactService;
	private CatPicService catPicService;

	public CatController(CatCardDao catCardDao, CatFactService catFactService, CatPicService catPicService) {
		this.catCardDao = catCardDao;
		this.catFactService = catFactService;
		this.catPicService = catPicService;
	}

	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
	public CatCard getIndividualCard(@PathVariable int id) {

		CatCard catCard;
		try {
			catCard = catCardDao.getCatCardById(id);
		} catch (DaoException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (catCard == null) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "CatCard not found");
		}
		return catCard;
	}

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public List<CatCard> getAllCards() {
		return catCardDao.getCatCards();
	}

	@RequestMapping("/random")
	public CatCard makeNewCard() {
		CatPic p = catPicService.getPic();
		CatCard c = new CatCard();
		c.setImgUrl(p.getFile());
		return c;
	}

	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(path = "/", method = RequestMethod.POST)
	public void saveNewCard(@Valid @RequestBody CatCard incomingCard) {
		catCardDao.createCatCard(incomingCard);
	}

	@ResponseStatus(HttpStatus.OK)
	@RequestMapping(path = "/{id}", method = RequestMethod.PUT)
	public void updateExistingCard(@Valid @RequestBody CatCard changedCard, @PathVariable int id) {
		CatCard catCardNew = new CatCard();
		catCardNew.setCatCardId(id);
		catCardNew.setCaption(changedCard.getCaption());
		catCardNew.setCatFact(changedCard.getCatFact());
		catCardNew.setImgUrl(changedCard.getImgUrl());
		catCardDao.createCatCard(catCardNew);
	}

	@ResponseStatus(HttpStatus.NO_CONTENT)
	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
	public void deleteExistingCard(@PathVariable int id) {
		catCardDao.deleteCatCardById(id);
	}
}
